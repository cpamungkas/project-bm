<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $session = session();
        $data['url'] = $this->request->uri->getSegment(1);
        if (!$session->get('isLoggedIn')) {
            return view('vLogin');
        } else {
            if (session()->get('level') == 99) {
                return redirect()->to('/admin');
            } elseif (session()->get('level') == 1) {
                return redirect()->to('/manager'); //dashboard manager
            } elseif (session()->get('level') == 2) {
                return redirect()->to('/supervisor'); //dashboard superior or superintendent
            } elseif (session()->get('level') == 3) {
                return redirect()->to('/worker'); //dashboard worker or user
            } else {
                return redirect()->to('/');
            }
        }
    }
}
